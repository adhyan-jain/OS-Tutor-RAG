import hashlib, json, os, subprocess, sys, time
ROOT = sys.argv[1]; STAGE = sys.argv[2]
def h(p):
    raw = open(p,'rb').read()
    try:
        d = json.loads(raw)
        def strip(o):
            if isinstance(o, dict): return {k: strip(v) for k, v in o.items() if k != 'provenance'}
            if isinstance(o, list): return [strip(x) for x in o]
            return o
        return hashlib.sha256(json.dumps(strip(d), sort_keys=True).encode()).hexdigest()
    except Exception:
        return hashlib.sha256(raw).hexdigest()
steps = [
 ("pytest: research/second-domain tests", "python3 -m pytest -p no:cacheprovider -q tests/ssr_pilot tests/test_second_domain_confirmatory.py tests/test_second_domain_pilot.py", None),
 ("pytest: full bundled tests dir", "python3 -m pytest -p no:cacheprovider -q tests", None),
 ("reference-space verification", "python3 -m research.pilot_second_domain.verify_reference_spaces", "research/pilot_second_domain/results/reference_space_verification.json"),
 ("blocks-world confirmatory analysis", "python3 -m research.pilot_second_domain.analyze_blocks_world_confirmatory", "research/pilot_second_domain/results/blocks_world_confirmatory.json"),
 ("blocks-world supplementary analysis", "python3 -m research.pilot_second_domain.analyze_blocks_world_supplementary", "research/pilot_second_domain/results/blocks_world_supplementary.json"),
 ("OS exact DP", "python3 -m research.ssr_pilot.rcr_exact_dp_analysis", "research/ssr_pilot/results/rcrc/exact_dp_analysis.json"),
 ("OS uncertainty audit", "python3 -m research.ssr_pilot.rcr_uncertainty_and_error_audit", "research/ssr_pilot/results/rcrc/uncertainty_audit.json"),
 ("OS extended analysis (50k draws x 20k flips)", "python3 -m research.ssr_pilot.rcr_extended_analysis", "research/ssr_pilot/results/rcrc/extended_analysis.json"),
]
res = []
for name, cmd, art in steps:
    t = time.time()
    p = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True,
                       env={**os.environ, "PYTHONPATH": ROOT})
    r = {"step": name, "command": cmd, "exit_code": p.returncode, "seconds": round(time.time()-t, 1),
         "tail": (p.stdout + p.stderr).strip().splitlines()[-3:]}
    if art:
        a, b = os.path.join(ROOT, art), os.path.join(STAGE, art)
        r["artifact"] = art
        r["output_identical_to_shipped_ignoring_provenance_metadata"] = h(a) == h(b)
    res.append(r); print(name, r["exit_code"], r.get("output_identical_to_shipped_ignoring_provenance_metadata"), r["seconds"], flush=True)
json.dump({"run_in": "fresh extraction of the zip, empty directory", "steps": res}, open(sys.argv[3], "w"), indent=2)
