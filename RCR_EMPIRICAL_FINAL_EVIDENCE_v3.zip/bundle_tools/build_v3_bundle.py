"""
Builds RCR_EMPIRICAL_FINAL_EVIDENCE_v3.zip in two phases (see --phase).
  stage : copy the evidence set into a staging dir and write diffs
  final : after standalone reproduction, write MANIFEST.json (SHA-256 of every file) and zip
Run from the repository root.
"""
import argparse, hashlib, json, os, shutil, subprocess, sys, zipfile

REPO = os.getcwd()
STAGE = os.environ["V3_STAGE"]
FILES = [
    "paper/RCR_EMPIRICAL_DRAFT.md", "paper/RCR_EMPIRICAL_DRAFT_v2_preconfirmatory.md",
    "paper/RCR_EMPIRICAL_READINESS.md", "paper/RCR_THEORY_CONTRIBUTION_DECISION.md",
    "paper/claims_manifest.json", "paper/REPRODUCIBILITY.md", "paper/references_verified.csv",
    "paper/review_bundle/CLAIM_TO_CODE_DATA_MAPPING.md",
    "research/docs/RCR_THEORY_GATE.md", "research/docs/RCR_EVIDENCE_AUDIT_AND_CORRECTIONS.md",
    "research/docs/RCR_FORMAL_METHOD_NOTE.md", "research/docs/TIE_HANDLING_ANALYSIS.md",
    "research/docs/SECOND_DOMAIN_PREREGISTRATION.md",
    "pytest.ini", "requirements.txt", "research/__init__.py", "src/__init__.py",
]
DIRS = ["research/ssr_pilot", "research/pilot_second_domain", "research/benchmark", "research/evaluation",
        "research/simulator", "src/mechanism", "src/verification", "tests", "paper", "docs/research"]
SKIP_PARTS = {"__pycache__", ".pytest_cache", ".venv"}
SKIP_SUFFIX = (".pyc", ".zip")


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def all_files(root):
    out = []
    for d, ds, fs in os.walk(root):
        ds[:] = [x for x in ds if x not in SKIP_PARTS]
        for f in fs:
            if not f.endswith(SKIP_SUFFIX):
                out.append(os.path.relpath(os.path.join(d, f), root))
    return sorted(out)


def sh(*a):
    return subprocess.run(a, capture_output=True, text=True, cwd=REPO).stdout


def stage():
    if os.path.exists(STAGE):
        shutil.rmtree(STAGE)
    os.makedirs(STAGE)
    missing = []
    for rel in FILES:
        if os.path.exists(rel):
            os.makedirs(os.path.dirname(os.path.join(STAGE, rel)) or STAGE, exist_ok=True)
            shutil.copy2(rel, os.path.join(STAGE, rel))
        else:
            missing.append(rel)
    for d in DIRS:
        for rel in all_files(d):
            src = os.path.join(d, rel)
            dst = os.path.join(STAGE, src)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
    # changed-file diffs: tracked changes + untracked text sources/docs that are in the bundle
    tracked = sh("git", "diff", "HEAD")
    untracked = sh("git", "ls-files", "--others", "--exclude-standard").split()
    extra = []
    for u in untracked:
        if u.endswith((".py", ".md", ".csv")) and os.path.exists(os.path.join(STAGE, u)):
            extra.append(subprocess.run(["git", "diff", "--no-index", "--", "/dev/null", u],
                                        capture_output=True, text=True, cwd=REPO).stdout)
    with open(os.path.join(STAGE, "CHANGED_FILES_v3.diff"), "w") as f:
        f.write("# Tracked-file changes (git diff HEAD), then new untracked sources/docs.\n")
        f.write("# Base commit: " + sh("git", "rev-parse", "HEAD").strip() + "\n")
        f.write(tracked + "\n" + "\n".join(extra))
    print("staged", len(all_files(STAGE)), "files; missing:", missing)


def final():
    pkg = {}
    try:
        import numpy, scipy, requests, pytest
        pkg = {"numpy": numpy.__version__, "scipy": scipy.__version__,
               "requests": requests.__version__, "pytest": pytest.__version__}
    except Exception as e:
        pkg = {"error": str(e)}
    pm = json.load(open(os.path.join(STAGE, "research/pilot_second_domain/manifest.json")))
    repro = json.load(open(os.path.join(STAGE, "REPRODUCTION_RESULTS.json")))
    manifest = {
        "bundle": "RCR_EMPIRICAL_FINAL_EVIDENCE_v3",
        "source_commit": sh("git", "rev-parse", "HEAD").strip(),
        "commit_subject": sh("git", "log", "-1", "--format=%s").strip(),
        "working_tree": "DIRTY: files below are uncommitted changes on top of source_commit; nothing was committed or pushed",
        "git_status_short": sh("git", "status", "--short").splitlines(),
        "environment": {
            "python": sys.version.split()[0], "packages": pkg,
            "os": sh("uname", "-sr").strip(),
            "hardware": pm.get("environment"),
            "llm_runtime": "Ollama (local); model digests in models below",
            "models": pm.get("models"),
            "external_dependencies": [
                "Re-running generation needs a local Ollama daemon with the four models; analysis from the "
                "frozen JSONL records does NOT.",
                "The bundle contains research/, tests/ and selected paper/ files only. The RAG application "
                "code is not included, so tests that import it are excluded from standalone reproduction."],
        },
        "reproduction": repro,
        "sha256": {rel: sha256(os.path.join(STAGE, rel)) for rel in all_files(STAGE) if rel != "MANIFEST.json"},
    }
    json.dump(manifest, open(os.path.join(STAGE, "MANIFEST.json"), "w"), indent=2)
    out = os.path.join(REPO, "RCR_EMPIRICAL_FINAL_EVIDENCE_v3.zip")
    if os.path.exists(out):
        raise SystemExit("refusing to overwrite " + out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in all_files(STAGE):
            z.write(os.path.join(STAGE, rel), rel)
    print("wrote", out, os.path.getsize(out))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--phase", choices=["stage", "final"], required=True)
    a = ap.parse_args()
    stage() if a.phase == "stage" else final()
