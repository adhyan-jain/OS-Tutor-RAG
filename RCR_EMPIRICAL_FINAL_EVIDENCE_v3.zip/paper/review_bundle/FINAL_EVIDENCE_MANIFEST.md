# Final Evidence Bundle Manifest: RCR Empirical Methodology

**Bundle Archive:** `RCR_EMPIRICAL_FINAL_EVIDENCE.zip`  
**Generated Date:** 2026-10-13  
**Repository Commit:** `81b9c7056464aa6d4049b6645201242d18fcba78` (plus uncommitted research docs and replication bundle)  
**Test Suite Status:** 420 passed in 15.29s (0 failures)

---

## Included Files and Cryptographic Checksums (SHA-256)

| Relative Path | SHA-256 Checksum | Description |
| :--- | :--- | :--- |
| `paper/RCR_EMPIRICAL_DRAFT.md` | `8ecf513320d0c46b095d71c4b22e75c61529c8b526a304593e3e357a3907736d` | Hardened empirical manuscript draft |
| `paper/RCR_EMPIRICAL_READINESS.md` | `c7ffe8be10132e66235230d63373545616d351f7c0e96f43a0f48796737af470` | Critical publication readiness evaluation memo |
| `research/docs/RCR_THEORY_GATE.md` | `6e6b84cbace3438f9b938210a57ebe5717407fb3683c8da3ac3a8c37b4af9045` | Priority 1 formal theory evaluation decision memo |
| `research/docs/RCR_EVIDENCE_AUDIT_AND_CORRECTIONS.md` | `95977ef032a3057e688b93add2783f946f1a783d6187e8db2deb5574fb80fdd7` | Numerical reconciliation and forensic audit memo |
| `research/docs/SECOND_DOMAIN_PREREGISTRATION.md` | `ebfd3bd95087902662eab86ec3adfc9b40ba714d1ef69f612c933387c6b1f6ed` | Preregistration for Blocks World classical planning |
| `research/pilot_second_domain/blocks_world_rcr_pilot.py` | `a31174a2f53fc81eeaba9f29f26d2012e4e315f8f4fa0d24d82916f3453ccb14` | STRIPS implementation check and DP pilot script |
| `research/pilot_second_domain/results/blocks_world_pilot.json` | `60f2bfc8c45b740e26abe843471eaea2465abda052282fc5cfd5a491b2173219` | Output data from Blocks World pilot execution |
| `tests/test_second_domain_pilot.py` | `6cdded5c50bf802a6ce94f376a3a915d5c2437a98288be2dc62ce8c64b9e3983` | Automated unit tests for second-domain pilot |
| `paper/review_bundle/test_execution.log` | `6b845519fbc8de191207b8fa9e350b85cfacdcd2b89b432f96ac88090b7fc7ba` | Full pytest log (420 passed) |

---

## Exact Reproduction Commands

```bash
# 1. Run the entire pytest suite:
pytest -v

# 2. Run the second-domain implementation check:
python3 research/pilot_second_domain/blocks_world_rcr_pilot.py

# 3. Verify exact DP convolution on OS benchmarks:
python3 paper/review_bundle/rcr_exact_dp_analysis.py
```
