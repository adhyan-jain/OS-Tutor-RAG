# RCR Rescue Evidence Bundle Manifest

**Repository:** OS-Tutor-RAG / Reference-Choice Robustness (RCR)  
**Date:** October 2026  
**Document Status:** Complete Deliverables & Provenance Manifest  
**Bundle Archive:** `paper/review_bundle/RCR_RESCUE_EVIDENCE_BUNDLE.zip`

---

## 1. Summary of Completed Deliverables

This bundle provides the complete, self-contained evidence package for the RCR Research Rescue mission across both theoretical and empirical tracks.

### Track A: Theoretical Investigation
- **Verdict Document**: [`research/docs/RCR_THEORY_GATE.md`](file:///home/adhyan/Desktop/OS_RAG/research/docs/RCR_THEORY_GATE.md)
  - Comprehensive prior-art matrix evaluating Casola et al. (INLG 2025), Kulshreshtha et al. (arXiv:2610.03825, Oct 2026), Feng et al. (arXiv:2608.25654, Aug 2026), Manski partial identification, and Mazurkiewicz trace theory.
  - Mathematical investigations, proofs, counterexamples, and stripping-notation tests for Candidates A, B, and C.
  - Simulated adversarial reviewer attacks (CAV/POPL/COLT and ACL/NeurIPS).
  - Hard decision gate verdict: **FAIL**.

### Track B: Empirical Methodology Paper
- **Empirical Manuscript**: [`paper/RCR_EMPIRICAL_DRAFT.md`](file:///home/adhyan/Desktop/OS_RAG/paper/RCR_EMPIRICAL_DRAFT.md)
  - Complete, scholarly, submission-ready empirical paper with bounded OS-domain framing.
  - Formal framework, exact DP results ($17.15\%$), Monte Carlo validation ($17.18\%$), near-tie decomposition ($85.6\%$), detection loss ($99.99\%$), and exact closed-form attenuation law ($\mathbb{E}[S_m] = S_m^{E3}/|V|$).
  - Full process disclosures (deviations D1–D10) and threats to validity.
- **Readiness & Venue Assessment**: [`paper/RCR_EMPIRICAL_READINESS.md`](file:///home/adhyan/Desktop/OS_RAG/paper/RCR_EMPIRICAL_READINESS.md)
  - Honest tier classification: Tier 2 (Submission-Ready for workshop/benchmarking tracks), Tier 1.5 for competitive main conference tracks.
  - Venue analysis across NeurIPS Datasets & Benchmarks, EMNLP, ICSE/ASE, and premier workshops.
- **Evidence Audit & Corrections**: [`research/docs/RCR_EVIDENCE_AUDIT_AND_CORRECTIONS.md`](file:///home/adhyan/Desktop/OS_RAG/research/docs/RCR_EVIDENCE_AUDIT_AND_CORRECTIONS.md)
  - Independent tracing and mathematical resolution of all five evidence gaps:
    1. TV robustness certificate (sufficient condition vs sign invariance; verified counterexample; empirical proof of sign stability).
    2. Reconciliation of reversal figures (historical 18.61%, corrected MC 17.56%, 17.23%, 17.18%, and exact DP 17.1518%; reporting mean signed error $+0.000252$, MAE $0.000643$, max AE $0.001385$).
    3. Detection loss audit (tracing the 99.99% figure to all 50,000 draws under world-level paired sign-flip permutation tests; guarding against equating nonsignificance with equivalence).
    4. Attenuation law audit (separating task-level identity from benchmark expectation; task weighting by $\frac{1}{|V_i|}$; recomputing retention ratios: 15–16% for separated pairs, 12–18% across non-trivial gaps).
    5. Test suite execution log and checksum analysis.

### Second-Domain Replication Artifacts
- **Preregistration Protocol**: [`research/docs/SECOND_DOMAIN_PREREGISTRATION.md`](file:///home/adhyan/Desktop/OS_RAG/research/docs/SECOND_DOMAIN_PREREGISTRATION.md)
  - Preregistered replication protocol for Discrete Planning (Blocks World).
  - Formal state transition semantics, all-shortest-paths BFS valid-space enumerator, four testable hypotheses (H1–H4), and power analysis.
- **Executable Pilot Script**: [`research/pilot_second_domain/blocks_world_rcr_pilot.py`](file:///home/adhyan/Desktop/OS_RAG/research/pilot_second_domain/blocks_world_rcr_pilot.py)
  - Pure Python STRIPS transition engine, BFS explorer, and exact DP margin convolution.
- **Pilot Results**: [`research/pilot_second_domain/results/blocks_world_pilot.json`](file:///home/adhyan/Desktop/OS_RAG/research/pilot_second_domain/results/blocks_world_pilot.json)
  - Verified attenuation law holds with mean observed/predicted ratio of 1.000000; pairwise winner reversal = 7.9861%.
- **Pilot Unit Test**: [`tests/test_second_domain_pilot.py`](file:///home/adhyan/Desktop/OS_RAG/tests/test_second_domain_pilot.py)
  - 100% passing pytest integration.

### Execution Logs & Code
- **Full Test Execution Log**: [`paper/review_bundle/RESCUE_TEST_EXECUTION.log`](file:///home/adhyan/Desktop/OS_RAG/paper/review_bundle/RESCUE_TEST_EXECUTION.log)
  - 418 passed tests across unit, regression, oracle, and rendering suites.

---

## 2. File Checksum Table (SHA-256)

| File Path | SHA-256 Checksum | Description |
|---|---|---|
| `research/docs/RCR_THEORY_GATE.md` | `6e6b84cbace3438f9b938210a57ebe5717407fb3683c8da3ac3a8c37b4af9045` | Formal Theory Gate Decision Memo |
| `paper/RCR_EMPIRICAL_DRAFT.md` | `07691e14246b757ded5ab55c8a7eeca1e31791eedd614417752c393210b3e24f` | Empirical Manuscript Draft |
| `paper/RCR_EMPIRICAL_READINESS.md` | `c7ffe8be10132e66235230d63373545616d351f7c0e96f43a0f48796737af470` | Publication Readiness and Venue Fit Memo |
| `research/docs/RCR_EVIDENCE_AUDIT_AND_CORRECTIONS.md` | `95977ef032a3057e688b93add2783f946f1a783d6187e8db2deb5574fb80fdd7` | Forensic Claim and Evidence Audit |
| `research/docs/SECOND_DOMAIN_PREREGISTRATION.md` | `cd1c75f241339d01330d3457a76a2294c4e0144ada84c2408ba9707a47615a6a` | Second-Domain Preregistered Protocol |
| `research/pilot_second_domain/blocks_world_rcr_pilot.py` | `a31174a2f53fc81eeaba9f29f26d2012e4e315f8f4fa0d24d82916f3453ccb14` | Second-Domain Pilot Simulation Script |
| `research/pilot_second_domain/results/blocks_world_pilot.json` | `60f2bfc8c45b740e26abe843471eaea2465abda052282fc5cfd5a491b2173219` | Second-Domain Machine-Readable Pilot Data |
| `tests/test_second_domain_pilot.py` | `6cdded5c50bf802a6ce94f376a3a915d5c2437a98288be2dc62ce8c64b9e3983` | Second-Domain Pytest Suite |
| `paper/review_bundle/RESCUE_TEST_EXECUTION.log` | `61c0485014a4fee593b91233893b52b49e2112e670da2db4d7f235f18f931ab0` | Full Automated Test Suite Execution Log |
| `research/ssr_pilot/rcrc/exact_margin_distribution.py` | `c0c10101d9334ad8f4efb5f909787a4eb8e17af9b94895ad2dc3989f799aefe2` | Dynamic Programming Margin Convolutions |
| `research/ssr_pilot/rcrc/robustness_certificate.py` | `487a551f51073b91e4376242bb76714aa0123eee0bff2e9ad06dec1fae2358c5` | Total-Variation Bound Formulations |
| `research/ssr_pilot/rcr_exact_dp_analysis.py` | `08070498b39a9d3b02fefccb1abd79101382d85d869e91a35632e4f0ea25feb0` | Exact DP Analysis Runner |
| `research/ssr_pilot/results/rcrc/exact_dp_analysis.json` | `ec51c834ce42d6aeb894c977e753642cef3ab4a2d90eabb0e7601ce95e99db0b` | Frozen Exact DP Machine-Readable Output |
| `research/ssr_pilot/results/rcrc/kref_attenuation.json` | `25ff06fbb27f8862241b8e6f0304223760a890ca73a5e871b547b0b33119472f` | Frozen Attenuation Law Results |
