# Evidence Manifest: RCR Post-Audit Resolution

**Date:** 2026-10-13  
**Base Commit SHA:** `81b9c7056464aa6d4049b6645201242d18fcba78`  
**Current Branch:** `main` (clean working tree on tracked files; user working tree changes preserved)  
**Package Scope:** Complete evidence bundle resolving the four post-audit issues.

---

## 1. Environment & Execution Context

- **OS / Platform:** Linux 7.2.4-arch1-2-x86_64
- **Python Version:** 3.14.7 (`.venv/bin/python`)
- **Key Packages:** `numpy==2.5.1`, `scipy==1.18.0`, `pytest==9.1.1`
- **Model Inference Re-runs:** None (all calculations executed strictly from frozen 1,152 generations in `research/ssr_pilot/runs/*.jsonl`).

---

## 2. Evidence Files and SHA-256 Checksums

| File | Description | SHA-256 Checksum |
|---|---|---|
| `exact_margin_distribution.py` | Exact discrete DP pairwise margin convolution algorithm | `c0c10101d9334ad8f4efb5f909787a4eb8e17af9b94895ad2dc3989f799aefe2` |
| `robustness_certificate.py` | Total variation robustness certificate (sufficient condition) | `487a551f51073b91e4376242bb76714aa0123eee0bff2e9ad06dec1fae2358c5` |
| `test_exact_margin_distribution.py` | Automated test suite (13 unit and counterexample tests) | `c7f93e5cbc7fa70f5601d8da15b36a1f61ae93a9c507f9ee11d2d3c62c90012f` |
| `rcr_exact_dp_analysis.py` | Execution driver computing exact margins from frozen data | `08070498b39a9d3b02fefccb1abd79101382d85d869e91a35632e4f0ea25feb0` |
| `exact_dp_analysis.json` | Exact results artifact for all 6 model pairs across evaluators | `ec51c834ce42d6aeb894c977e753642cef3ab4a2d90eabb0e7601ce95e99db0b` |
| `RCR_FORMAL_METHOD_NOTE.md` | Formal method note: proofs, identities, complexity, counterexample | `0b2fec5cd9333a229ecf3c596795ddedab086430f5a2a71257e05139d080b17b` |
| `TIE_HANDLING_ANALYSIS.md` | Audit analysis of tie-handling estimands and hand-constructed example | `db2de4981ab65849e3b4fb38dfe9d3d757e4af7cea4653ef71df9b72f07ddcd8` |
| `RCR_THEORY_CONTRIBUTION_DECISION.md` | Architectural decision memo establishing publication verdict (NO-GO) | `284248de1d9b620feadc5e515831d096841a6142016fb6410435e380d475da8e` |
| `AUDIT_DIFFS.patch` | Git diff patch of modified files in repository | `87ca3cd022f1aea7b19bd5e51aa52093e344072dfe8b46ec0f157e5989415bd0` |
| `TEST_EXECUTION.log` | Complete passing pytest log (30 tests: 13 exact DP + 17 extended analysis) | `8299bbc5335f7d4d8bf81f4dc2c6f2c0a1e1d4af0136d58055965f42a68afc96` |

---

## 3. Verification Commands Executed

1. Exact DP dataset evaluation:
   ```bash
   python -m research.ssr_pilot.rcr_exact_dp_analysis
   ```
2. Automated test execution:
   ```bash
   python -m pytest tests/ssr_pilot/test_exact_margin_distribution.py tests/ssr_pilot/test_extended_analysis.py -v
   ```
   Result: **30 / 30 passed in 0.78s**.
