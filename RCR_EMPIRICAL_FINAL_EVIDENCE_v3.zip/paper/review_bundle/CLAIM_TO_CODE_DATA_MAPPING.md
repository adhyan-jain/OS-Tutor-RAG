# RCR Empirical Methodology: Claim-to-Code-to-Data Mapping

This document provides a trace for every empirical claim in the manuscript (`paper/RCR_EMPIRICAL_DRAFT.md`), linking the mathematical claim directly to the executable script, input data, and output JSON artifact.

---

## 1. Exact Population Reversal Parameter (17.1518%)
- **Claim:** The exact pairwise winner reversal rate under independent uniform reference selection is 17.1518% (mean across 6 model pairs).
- **Executable Script:** `research/ssr_pilot/rcr_exact_dp_analysis.py` (calling `research/ssr_pilot/rcrc/exact_margin_distribution.py`)
- **Input Data:** Score tensors generated from frozen generations in `research/ssr_pilot/runs/` across 24 worlds.
- **Output Artifact:** `research/ssr_pilot/results/rcrc/exact_dp_analysis.json` (`evaluators.E2_NORMALIZED_MATCH.mean_pairwise_reversal_probability = 0.17151800998238678`)
- **Unit Test:** `tests/ssr_pilot/test_exact_margin_distribution.py::test_enumeration_vs_dp`

---

## 2. Degree-2 U-Statistic Monte Carlo Uncertainty & Error
- **Claim:** Across 50,000 draws, the estimated mean reversal rate is 17.1770%. Mean signed error (MC - Exact) is +0.00025224, MAE is 0.00064349, and MaxAE is 0.00138474. Due to joint dependencies among pairs sharing candidate models, the variance is inflated by $\mathrm{VIF} = 1.6203$, giving $\mathrm{SE}_{\mathrm{joint}} = 0.00090606$ ($z = +0.2784$, $p = 0.781$).
- **Executable Script:** `research/ssr_pilot/rcr_uncertainty_and_error_audit.py`
- **Input Data:** `research/ssr_pilot/results/rcrc/exact_dp_analysis.json` and 50,000 reference vectors sampled from `research/ssr_pilot/runs/`.
- **Output Artifact:** `research/ssr_pilot/results/rcrc/uncertainty_audit.json`
- **Unit Test:** `tests/ssr_pilot/test_uncertainty_audit.py` (4 tests)

---

## 3. Score Attenuation Law ($\mathbb{E}[S_m] = S_m^* / |V_i|$)
- **Claim:** For any task where candidate solutions match at most one valid reference, expected single-reference score equals the semantic pass rate divided by the valid space cardinality ($r = 1.000000$, observed/predicted ratio = $1.000000$). Margin retention on separated pairs is 15.05% to 15.80%.
- **Executable Script:** `research/ssr_pilot/rcr_reference_distribution_sensitivity.py`
- **Input Data:** `research/ssr_pilot/runs/*.jsonl`
- **Output Artifact:** `research/ssr_pilot/results/rcrc/reference_distribution_sensitivity.json`
- **Unit Test:** `tests/test_consistency_gate.py::test_reference_distribution_sensitivity_monotonic_attenuation`

---

## 4. Statistical Detection Power Collapse (99.99%)
- **Claim:** Under reference-independent semantic evaluation ($E_3$), Qwen-3 is significantly superior to LLaMA-3.1 ($p = 0.0126$) and Mistral ($p = 0.0175$). Single-reference matching ($E_2$) misses these separations in 49,995 of 50,000 draws (99.99% detection loss).
- **Executable Script:** `research/ssr_pilot/rcr_extended_analysis.py`
- **Input Data:** `research/ssr_pilot/runs/*.jsonl`
- **Output Artifact:** `research/ssr_pilot/results/rcrc/extended_analysis.json` (`detection_vs_oracle.E2_NORMALIZED_MATCH`)
- **Unit Test:** `tests/ssr_pilot/test_extended_analysis.py::test_oracle_separates_exactly_the_qwen3_pairs`

---

## 5. Near-Tie Decomposition of Ranking Instability (85.63%)
- **Claim:** 85.63% of total pairwise reversal probability mass falls within the 4 model pairs that the oracle cannot separate at $N=24$. On genuinely separated pairs, the mean reversal rate is 7.41%.
- **Executable Script:** `research/ssr_pilot/rcr_extended_analysis.py`
- **Input Data:** `research/ssr_pilot/results/rcrc/extended_analysis.json`
- **Output Artifact:** `research/ssr_pilot/results/rcrc/extended_analysis.json` (`near_tie_decomposition.E2_NORMALIZED_MATCH`)
- **Unit Test:** `tests/ssr_pilot/test_extended_analysis.py::test_near_tie_decomposition_sums_to_total_reversals`

---

## 6. Prompting Ineffectiveness (Failure of Stated Conventions)
- **Claim:** Instructing models with the canonical convention prompt does not eliminate non-canonical valid solutions ($\text{FRR}_{\mathrm{norm}} = 0.625$ on sub-10B models; $0.619$ on Gemma 3 12B).
- **Executable Script:** `research/ssr_pilot/rcrc/analysis.py`
- **Input Data:** `research/ssr_pilot/runs_stated_convention/*.jsonl`
- **Output Artifact:** `research/ssr_pilot/results/stated_convention/analysis.json`
- **Unit Test:** `tests/ssr_pilot/test_stated_convention_prompt.py`

---

## 7. Second-Domain Replication (Blocks World Classical Planning)
- **Claim:** Complete deterministic STRIPS state transitions, all-shortest-paths BFS level-synchronous enumeration, and dynamic programming margin convolution verified in discrete classical planning. Confirmatory 1,152-generation LLM experiment formally preregistered.
- **Executable Script:** `research/pilot_second_domain/blocks_world_rcr_pilot.py`
- **Input Data:** STRIPS planning definitions in `define_benchmark_worlds()`
- **Output Artifact:** `research/pilot_second_domain/results/blocks_world_pilot.json`
- **Unit Test:** `tests/test_second_domain_pilot.py` (2 tests)

---

## 7. Blocks World confirmatory study (v3 additions)

All Blocks World claims below concern the **confirmatory** run (actual local-model generations). The 6-world pilot (`blocks_world_rcr_pilot.py`, synthetic candidates) supports no behavioral claim.

| # | Claim (manuscript §6) | Script | Input data | Output artifact | Test |
|---|---|---|---|---|---|
| 7.1 | 1,152 / 1,152 planned generations present, 0 errors, registered settings | `run_blocks_world_confirmatory.py` | `research/pilot_second_domain/runs/*.jsonl` | same | `tests/test_second_domain_confirmatory.py::test_confirmatory_runs_account_for_every_planned_generation` |
| 7.2 | No reference plan appears in any prompt | `blocks_world_tasks.py::render_task_prompt` | task definitions | n/a | `::test_prompts_contain_no_reference_plan` |
| 7.3 | 24 / 24 reference spaces (all shortest paths) match an independent IDDFS enumeration | `verify_reference_spaces.py` | `blocks_world_tasks.py::get_all_tasks` | `results/reference_space_verification.json` | `::test_reference_spaces_independently_verified`, `::test_bfs_shortest_paths_validity` |
| 7.4 | Valid generations 23 / 16 / 1 / 1; pass rates 7.99 / 5.56 / 0.35 / 0.35% | `analyze_blocks_world_confirmatory.py` | `runs/*.jsonl` | `results/blocks_world_confirmatory.json` (`semantic_pass_rates`) | `::test_confirmatory_result_statuses_not_vacuous` |
| 7.5 | H1: r = 0.9855 over 16 non-zero cells, median ratio 1.000 | `analyze_blocks_world_confirmatory.py` | `runs/*.jsonl` | `results/blocks_world_confirmatory.json` (`H1_attenuation_law`) | same |
| 7.6 | H2: mean exact-DP reversal 4.63% (qwen3 vs gemma2 27.78%, other pairs 0) | `analyze_blocks_world_confirmatory.py` -> `rcrc/exact_margin_distribution.py` | `runs/*.jsonl` | `results/blocks_world_confirmatory.json` (`H2_ranking_instability`) | `tests/ssr_pilot/test_exact_margin_distribution.py` |
| 7.7 | H3 not informative, H4 not testable (no E3-separated pair; smallest Holm p = 0.0975) | `analyze_blocks_world_confirmatory.py` | `runs/*.jsonl` | `results/blocks_world_confirmatory.json` (`status` fields) | `::test_confirmatory_result_statuses_not_vacuous` |
| 7.8 | Generation / task bootstrap intervals, failure taxonomy, prompt-surface effect, canonical-bias sensitivity, E1 = E2, exploratory 50k x 20k detection | `analyze_blocks_world_supplementary.py` | `runs/*.jsonl` | `results/blocks_world_supplementary.json` | executed by the bundle reproduction commands |
| 7.9 | As-executed (pre-correction) output, preserved | `analyze_blocks_world_confirmatory.py` @ 2026-10-13 | `runs/*.jsonl` | `results/blocks_world_confirmatory_as_executed_20261013.json` | n/a (historical) |

## 8. Corrected OS-study items (v3)

| Item | Correction | Source |
|---|---|---|
| Abstract SE for the six-pair mean | 0.000906 (joint covariance); the earlier "0.00173" had no source artifact | `research/ssr_pilot/results/rcrc/uncertainty_audit.json` (`se_six_pair_mean_joint_covariance`) |
| "99.99% detection miss" | 49,995 / 50,000 draws, Wilson 95% [99.977%, 99.996%]; conditional on the 24 frozen worlds and generations | `extended_analysis.json` (`detection_vs_oracle.E2_NORMALIZED_MATCH`) |
| Stated-convention path | `research/ssr_pilot/results/stated_convention/analysis.json` | file listing |
