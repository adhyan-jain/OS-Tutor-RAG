# Final Evidence Bundle v2 Manifest: RCR Empirical Methodology

**Archive Name:** `RCR_EMPIRICAL_FINAL_EVIDENCE_v2.zip`  
**Generated Date:** 2026-10-13  
**Base Repository Commit:** `81b9c7056464aa6d4049b6645201242d18fcba78` (plus uncommitted research enhancements and evidence additions, fully documented in `CHANGED_FILES.diff`)  
**Test Suite Verification:** 424 passed out of 424 tests in 19.19s (cached) / 69.78s (cold) with 0 failures (Exit code: 0)

---

## 1. Environment & Dependencies

- **OS / Architecture:** Linux x86_64
- **Python Runtime:** Python 3.14.7 (compatible with Python >= 3.10)
- **Core Dependencies:** `pytest >= 9.1`, `numpy >= 1.24`, `anyio >= 4.1`
- **Inference Runtime:** Local Ollama daemon (`http://localhost:11434`)
  - Installed models: `qwen3:8b`, `llama3.1:8b`, `mistral:7b`, `gemma2:9b`
  - GPU: NVIDIA GeForce RTX 4060 Laptop GPU (8,188 MiB VRAM)
- **Paid APIs:** None ($0 cost; entirely local open-weights & deterministic execution)

---

## 2. Reproduction Commands & Exit Codes

| Step / Analysis | Executable Command | Expected Output | Exit Code |
|---|---|---|---|
| **1. Full Test Suite** | `pytest -v` | 424 passed (0 failures) | `0` |
| **2. Exact DP Convolution** | `PYTHONPATH=. python3 research/ssr_pilot/rcr_exact_dp_analysis.py` | `Exact DP E2 mean reversal: 0.171518` | `0` |
| **3. Uncertainty & Error Audit** | `PYTHONPATH=. python3 research/ssr_pilot/rcr_uncertainty_and_error_audit.py` | `Exact: 0.171518, MC: 0.171770, VIF: 1.6203, SE: 0.000906, z: +0.2784` | `0` |
| **4. Second-Domain Pilot** | `PYTHONPATH=. python3 research/pilot_second_domain/blocks_world_rcr_pilot.py` | `Attenuation Check: Mean Ratio = 1.000000; Pilot Reversals: alpha vs beta = 7.9861%` | `0` |

---

## 3. Core Packaged Files & SHA-256 Checksums

| Relative File Path | SHA-256 Checksum | Description |
|---|---|---|
| `paper/RCR_EMPIRICAL_DRAFT.md` | `a9308965e28ff8f449c6752e84c896a6e4cca503cd429797da00356c70e8f7fe` | Hardened empirical methodology draft with exact statistics and bounded claims |
| `paper/RCR_EMPIRICAL_READINESS.md` | `0788450acc1a7fea8c0c07cdc198f8eab845425172b8c5121e84e5e6dca37a1c` | Pre-submission publication readiness assessment and 7-point adversarial audit |
| `research/docs/RCR_THEORY_GATE.md` | `6e6b84cbace3438f9b938210a57ebe5717407fb3683c8da3ac3a8c37b4af9045` | Formal theory contribution gate record (FAIL verdict; retained for provenance) |
| `research/docs/RCR_EVIDENCE_AUDIT_AND_CORRECTIONS.md` | `9940cd24aee27a1bb21ec22824ddc28fc189175a13c718fca5409b016b8f6796` | Comprehensive numerical reconciliation, U-statistic SE, and test history |
| `research/docs/SECOND_DOMAIN_PREREGISTRATION.md` | `ebfd3bd95087902662eab86ec3adfc9b40ba714d1ef69f612c933387c6b1f6ed` | Preregistration protocol for Blocks World classical planning replication |
| `paper/review_bundle/CLAIM_TO_CODE_DATA_MAPPING.md` | `3ab8b8eb7560b5ff423e672d4ecd61efd9d5eb3c855d388dad8a8b41372fe5dd` | Explicit audit trace mapping every manuscript claim to code and data artifacts |
| `paper/review_bundle/CHANGED_FILES.diff` | `456e0dadea74b03710e637f7b584476d04d390ad2ee2b3edfc4f3b734ce447df` | Complete unified diff of all uncommitted repository modifications |
| `paper/review_bundle/test_execution.log` | `a683a3ab1580d63709ae549a95f1b39b3cce7b1820e728456c275a356d993013` | Verbatim execution log recording 424 passed pytest tests |
| `research/ssr_pilot/rcr_uncertainty_and_error_audit.py` | `dcbb9d4c569f988537c0349982f5767f0b15d0c76517aba329ad1ff345c321b4` | Degree-2 U-statistic variance and joint covariance audit implementation |
| `research/ssr_pilot/results/rcrc/uncertainty_audit.json` | `07e05f3068ff440ea254ec387df106bea0f43616a4a1bd903c2f4f0e653cf9a7` | Serialized uncertainty and numerical reconciliation audit data |
| `research/ssr_pilot/rcr_exact_dp_analysis.py` | `08070498b39a9d3b02fefccb1abd79101382d85d869e91a35632e4f0ea25feb0` | Exact dynamic programming margin distribution runner |
| `research/ssr_pilot/results/rcrc/exact_dp_analysis.json` | `ec51c834ce42d6aeb894c977e753642cef3ab4a2d90eabb0e7601ce95e99db0b` | Output JSON artifact with exact closed-form reversal parameters |
| `research/pilot_second_domain/blocks_world_rcr_pilot.py` | `a31174a2f53fc81eeaba9f29f26d2012e4e315f8f4fa0d24d82916f3453ccb14` | Blocks World STRIPS transition model, BFS enumerator, and exact DP pilot |
| `research/pilot_second_domain/results/blocks_world_pilot.json` | `60f2bfc8c45b740e26abe843471eaea2465abda052282fc5cfd5a491b2173219` | Serialized pilot data verifying the 1/|V(x)| attenuation identity |
| `tests/ssr_pilot/test_uncertainty_audit.py` | `7117c5a638ffde58ee05ea3c0f0e4d006f2ed359a714dd41ec6e09d1ca161723` | Unit tests for degree-2 U-statistic properties, VIF, and error bounds |
| `tests/test_second_domain_pilot.py` | `6cdded5c50bf802a6ce94f376a3a915d5c2437a98288be2dc62ce8c64b9e3983` | Unit tests for Blocks World BFS enumeration and pilot mechanics |
