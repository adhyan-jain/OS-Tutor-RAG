# RCR_EMPIRICAL_FINAL_EVIDENCE_v3 — how to reproduce

Source: see `MANIFEST.json` (`source_commit`, `git_status_short`). The working tree was **dirty**; all changes
are in `CHANGED_FILES_v3.diff`. Nothing was committed.

## Requirements
Python 3.14 (tested 3.14.7), numpy 2.5.1, scipy 1.18.0, requests 2.34.2, pytest 9.1.1 (see `requirements.txt`).
No network, no paid API. Regenerating LLM outputs additionally needs a local Ollama daemon with the four model
digests listed in `MANIFEST.json`; **analysis from the frozen JSONL records does not**.

## Commands (run from the extracted root, `PYTHONPATH=.`)
```
python3 -m pytest -p no:cacheprovider -q tests                                # 432 passed
python3 -m research.pilot_second_domain.verify_reference_spaces               # ALL OK
python3 -m research.pilot_second_domain.analyze_blocks_world_confirmatory     # H1-H4 verdicts
python3 -m research.pilot_second_domain.analyze_blocks_world_supplementary    # ~1-2 min
python3 -m research.ssr_pilot.rcr_exact_dp_analysis
python3 -m research.ssr_pilot.rcr_uncertainty_and_error_audit
python3 -m research.ssr_pilot.rcr_extended_analysis                           # ~2-5 min
```
Run the tests BEFORE the analyses: the analyses rewrite result JSONs in place, and their `provenance`
block (timestamp, pid, git SHA = `unknown` outside a checkout) legitimately differs, which trips the
raw-SHA gate in `tests/test_consistency_gate.py`. Numerical content is identical (see `REPRODUCTION_RESULTS.json`,
which compares outputs with `provenance` stripped).

## Not in the bundle
Application code outside `research/` and `src/{mechanism,verification}`; the Ollama model weights.
`bundle_tools/` holds the scripts that built this archive and produced `REPRODUCTION_RESULTS.json`.
